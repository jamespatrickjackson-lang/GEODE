# GUI Workbench Docs Package

This package contains the v0.1 supporting definition/control documents for the GUI Workbench.

Target local path:

```text
C:\GeoSee\GeoSee_Dev\UI_EDITOR\docs
```

Files included:

1. `gui_workbench_glossary_naming_v0_1.md`
2. `gui_workbench_use_cases_user_roles_v0_1.md`
3. `gui_workbench_safe_editing_boundary_charter_v0_1.md`
4. `gui_workbench_gui_package_concept_note_v0_1.md`
5. `gui_workbench_validation_philosophy_v0_1.md`
6. `gui_workbench_goc_first_context_brief_v0_1.md`
7. `gui_workbench_reviewer_open_questions_index_v0_1.md`

The reviewer open questions index is the single-point unresolved-question document.

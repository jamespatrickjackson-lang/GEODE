$TargetDir = "C:\GeoSee\GeoSee_Dev\UI_EDITOR\docs"
New-Item -ItemType Directory -Force -Path $TargetDir | Out-Null
Copy-Item ".\GeoSee\GeoSee_Dev\UI_EDITOR\docs\*.md" -Destination $TargetDir -Force
Write-Host "Installed GUI Workbench supporting docs to $TargetDir"

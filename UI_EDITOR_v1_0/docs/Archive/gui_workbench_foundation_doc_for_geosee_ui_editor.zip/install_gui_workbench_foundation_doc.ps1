$TargetDir = "C:\GeoSee\GeoSee_Dev\UI_EDITOR\docs"
New-Item -ItemType Directory -Force -Path $TargetDir | Out-Null
Copy-Item ".\GeoSee\GeoSee_Dev\UI_EDITOR\docs\gui_workbench_project_outline_foundation_v0_1.md" -Destination $TargetDir -Force
Write-Host "Installed gui_workbench_project_outline_foundation_v0_1.md to $TargetDir"

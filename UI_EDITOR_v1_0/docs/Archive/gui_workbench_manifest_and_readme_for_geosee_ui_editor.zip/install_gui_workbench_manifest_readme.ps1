$TargetDir = "C:\GeoSee\GeoSee_Dev\UI_EDITOR\docs"
New-Item -ItemType Directory -Force -Path $TargetDir | Out-Null
Copy-Item ".\GeoSee\GeoSee_Dev\UI_EDITOR\docs\gui_workbench_docs_manifest_v0_1.md" -Destination $TargetDir -Force
Copy-Item ".\GeoSee\GeoSee_Dev\UI_EDITOR\docs\README_gui_workbench_docs_v0_1.md" -Destination $TargetDir -Force
Write-Host "Installed GUI Workbench manifest and README to $TargetDir"
